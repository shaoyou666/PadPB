package yoo.app.padpb;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.widget.Toast;

public class BGService extends Service {

    //private static KeyguardManager.KeyguardLock lock;
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        IntentFilter filter = new IntentFilter();
        filter.addAction("TimerClosed");
        registerReceiver(screenOffReceiver,filter);
    }
    //���չ����㲥
    BroadcastReceiver screenOffReceiver=new  BroadcastReceiver() {
        public void onReceive(final Context context, Intent intent){
            String action = intent.getAction();
            if(action.equals("TimerClosed")){
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(300000);
                            if(!FullscreenActivity.isActive){
                                Intent i =new Intent();
                                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                i.setClass(context, FullscreenActivity.class);
                                context.startActivity(i);
                            }
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        }
    };
    @Override
    public void onDestroy() {
        unregisterReceiver(screenOffReceiver);
    }

}
