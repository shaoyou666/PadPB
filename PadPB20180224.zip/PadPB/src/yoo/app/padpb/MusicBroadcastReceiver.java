package yoo.app.padpb;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MusicBroadcastReceiver extends BroadcastReceiver {

	String artistName,album,track;
	Boolean playing;
	Long duration,position;
	@Override
	public void onReceive(Context context, Intent intent) {
		// TODO Auto-generated method stub
		artistName = intent.getStringExtra("artist");
        album = intent.getStringExtra("album");
        track = intent.getStringExtra("track");
        playing = intent.getBooleanExtra("playing",false);
        duration = intent.getLongExtra("duration",3000);
        position = intent.getLongExtra("position",1000);
        if(playing)
        	Toast.makeText(context, "playing music", 0).show();
        //FullscreenActivity.this.tv_song.setText("playing music!");
	}

}
