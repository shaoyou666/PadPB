package yoo.app.padpb;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import yoo.app.padpb.util.SystemUiHider;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.KeyguardManager;
import android.app.KeyguardManager.KeyguardLock;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.support.v4.content.LocalBroadcastManager;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import android.widget.Toast;


/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 *
 * @see SystemUiHider
 */
public class FullscreenActivity extends Activity implements Runnable {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
	
	public  static  boolean isKeepRun;
    public static boolean isActive;
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    /**
     * If set, will toggle the system UI visibility upon interaction. Otherwise,
     * will show the system UI visibility upon interaction.
     */
    private static final boolean TOGGLE_ON_CLICK = true;

    /**
     * The flags to pass to {@link SystemUiHider#getInstance}.
     */
    private static final int HIDER_FLAGS = SystemUiHider.FLAG_HIDE_NAVIGATION;

    /**
     * The instance of the {@link SystemUiHider} for this activity.
     */
    private SystemUiHider mSystemUiHider;
    
    private Handler handler;
    public TextView tv_time,tv_date,tv_song;
    private Context mContext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_fullscreen);
        mContext = FullscreenActivity.this;
        final View controlsView = findViewById(R.id.fullscreen_content_controls);
        final View contentView = findViewById(R.id.fullscreen_content);

        // Set up an instance of SystemUiHider to control the system UI for
        // this activity.
        mSystemUiHider = SystemUiHider.getInstance(this, contentView, HIDER_FLAGS);
        mSystemUiHider.setup();
        mSystemUiHider
                .setOnVisibilityChangeListener(new SystemUiHider.OnVisibilityChangeListener() {
                    // Cached values.
                    int mControlsHeight;
                    int mShortAnimTime;

                    @Override
                    @TargetApi(Build.VERSION_CODES.HONEYCOMB_MR2)
                    public void onVisibilityChange(boolean visible) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
                            // If the ViewPropertyAnimator API is available
                            // (Honeycomb MR2 and later), use it to animate the
                            // in-layout UI controls at the bottom of the
                            // screen.
                            if (mControlsHeight == 0) {
                                mControlsHeight = controlsView.getHeight();
                            }
                            if (mShortAnimTime == 0) {
                                mShortAnimTime = getResources().getInteger(
                                        android.R.integer.config_shortAnimTime);
                            }
                            controlsView.animate()
                                    .translationY(visible ? 0 : mControlsHeight)
                                    .setDuration(mShortAnimTime);
                        } else {
                            // If the ViewPropertyAnimator APIs aren't
                            // available, simply show or hide the in-layout UI
                            // controls.
                            controlsView.setVisibility(visible ? View.VISIBLE : View.GONE);
                        }

                        if (visible && AUTO_HIDE) {
                            // Schedule a hide().
                            //delayedHide(AUTO_HIDE_DELAY_MILLIS);
                        	Intent intent = new Intent();
                            intent.setAction("TimerClosed");
                            FullscreenActivity.this.sendBroadcast(intent);
                            finish();
                        }
                    }
                });

        // Set up the user interaction to manually show or hide the system UI.
        contentView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TOGGLE_ON_CLICK) {
                    mSystemUiHider.toggle();
                } else {
                    mSystemUiHider.show();
                }
            }
        });
        tv_time = (TextView)findViewById(R.id.tv_time);
        tv_date = (TextView)findViewById(R.id.tv_date);
        handler = new Handler(){
        	public void handleMessage(Message msg){
        		if(msg.what==100)
        			tv_time.setText((String)msg.obj);
        		if(msg.what==200)
        			tv_date.setText((String)msg.obj);
        	}
        };
       
        startService(new Intent(FullscreenActivity.this,BGService.class));
        
        new Thread(this).start();
    }


	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Intent intent = new Intent();
        intent.setAction("TimerClosed");
        FullscreenActivity.this.sendBroadcast(intent);
	}


	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			while(true){
				
				SimpleDateFormat time = new SimpleDateFormat("HH:mm:ss");
				//SimpleDateFormat date = new SimpleDateFormat("yyyy��MM��dd��");   
				String str_time = time.format(new Date());
				/*String str_date = date.format(new Date());
				handler.sendMessage(handler.obtainMessage(100,str_time));//100 for time
				handler.sendMessage(handler.obtainMessage(200,str_date));//200 for time
				*/
				Calendar cal = Calendar.getInstance();
				int year = cal.get(Calendar.YEAR);//��ȡ���
		        int month=cal.get(Calendar.MONTH)+1;//��ȡ�·�
		        int day=cal.get(Calendar.DATE);//��ȡ��
		        //int hour=cal.get(Calendar.HOUR);//Сʱ
		        //int minute=cal.get(Calendar.MINUTE);//��           
		        //int second=cal.get(Calendar.SECOND);//��
		        int WeekOfYear = cal.get(Calendar.DAY_OF_WEEK)-1;//һ�ܵĵڼ���
		        //System.out.println("���ڵ�ʱ���ǣ���Ԫ"+year+"��"+month+"��"+day+"��      "+hour+"ʱ"+minute+"��"+second+"��       ����"+WeekOfYear);
		        CalendarUtil c = new CalendarUtil();
		        String ChineseDay = c.getChineseDay(year, month, day);
		        String ChineseMonth = c.getChineseMonth(year, month, day);
		        handler.sendMessage(handler.obtainMessage(100,str_time));//100 for time
				handler.sendMessage(handler.obtainMessage(200,year+"��"+month+"��"+day+"��    ����"+getWeek(WeekOfYear)+"   ũ��"+ChineseMonth+ChineseDay));//200 for time
				//getMusicInfo();
				Thread.sleep(1000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

    public String getWeek(int w){
    	switch(w){
    		case 1: return "һ";
    		case 2: return "��";
    		case 3: return "��";
    		case 4: return "��";
    		case 5: return "��";
    		case 6: return "��";
    		case 7: return "��";
    		default:return "";
    	}
    }
	@Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        // Trigger the initial hide() shortly after the activity has been
        // created, to briefly hint to the user that UI controls
        // are available.
        delayedHide(100);
    }


    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    View.OnTouchListener mDelayHideTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (AUTO_HIDE) {
                delayedHide(AUTO_HIDE_DELAY_MILLIS);
            }
            return false;
        }
    };

    Handler mHideHandler = new Handler();
    Runnable mHideRunnable = new Runnable() {
        @Override
        public void run() {
            mSystemUiHider.hide();
        }
    };

    /**
     * Schedules a call to hide() in [delay] milliseconds, canceling any
     * previously scheduled calls.
     */
    private void delayedHide(int delayMillis) {
        mHideHandler.removeCallbacks(mHideRunnable);
        mHideHandler.postDelayed(mHideRunnable, delayMillis);
    }
  
    @Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		isActive = true;
	}


	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		isActive  = false;
	}

    
}
